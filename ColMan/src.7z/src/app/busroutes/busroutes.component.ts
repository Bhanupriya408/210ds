import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-busroutes',
  templateUrl: './busroutes.component.html',
  styleUrls: ['./busroutes.component.css']
})
export class BusroutesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
