import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-driverdetails',
  templateUrl: './driverdetails.component.html',
  styleUrls: ['./driverdetails.component.css']
})
export class DriverdetailsComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }
}
