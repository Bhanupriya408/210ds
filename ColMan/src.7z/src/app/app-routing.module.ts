import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactusComponent } from './contactus/contactus.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';

import {SignupComponent} from './signup/signup.component';
import { BusroutesComponent } from './busroutes/busroutes.component';
import { DriverdetailsComponent } from './driverdetails/driverdetails.component';
const routes: Routes = [
  { path:'signup',component: SignupComponent},
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'contactus', component: ContactusComponent },
  { path: 'driverdetails', component: DriverdetailsComponent },
  { path: 'busroutes', component: BusroutesComponent },
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
