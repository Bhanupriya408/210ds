import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-ourservices',
  templateUrl: './ourservices.component.html',
  styleUrls: ['./ourservices.component.css']
})
export class OurservicesComponent implements OnInit {
  public services = [
    { id: 1, name: 'Driverdetails' },
    { id: 2, name: 'Busroutes' },
  ];
  constructor(public router: Router) { }
  
  ngOnInit(): void {}
  onClick(service: any) {
    this.router.navigate(['/ourservices',service.id])
  }


}
